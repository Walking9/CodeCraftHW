#ifndef CODE_H
#define CODE_H

#include <vector>
#include "init.h"

string firstFit();

string getPrintStr(int predictFlavorNum,vector<Server*>& servers);

#endif // CODE_H
